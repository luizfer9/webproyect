<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\modelocarrera;
use App\modeloalumnos;
use DB;

class alumnoscontroller extends Controller
{
   public function registrar(){
     $carreras=modelocarrera::all();
   	return view('registrarAlumno', compact('carreras'));
   }

   public function guardar(Request $datos){
     $alumnos=new modeloalumnos();
     $alumnos->nombre=$datos->input('nombre');
     $alumnos->numero_control=$datos->input('control');
     $alumnos->edad=$datos->input('edad');
     $alumnos->sexo=$datos->input('sexo');
     $alumnos->carrera_id=$datos->input('carrera');
     $alumnos->save();
     return redirect('/ejemplo2');
   }
   public function consultar (){
    // $alumnos=modeloalumnos::paginate(5);
    $alumnos=DB::table ('alumnos')
    ->join('carreras','alumnos.carrera_id','=','carreras.id')
    ->select('alumnos.*','carreras.nombre AS nom_carrera')
    ->paginate(5);
     return view('consultarAlumno',compact('alumnos'));
   }
   public function eliminar ($id){
     $alumnos=modeloalumnos::find($id);
     //dd($alumnos);
     $alumnos->delete();
     return redirect('consultarAlumno');
   }
   public function editar ($id){
     $alumnos=DB::table ('alumnos')
     ->where('alumnos.id','=',$id)
     ->join('carreras','alumnos.carrera_id','=','carreras.id')
     ->select('alumnos.*','carreras.nombre AS nom_carrera')
     ->first();
     $carreras=modelocarrera::all();
     return view('editarAlumno',compact('alumnos','carreras'));
   }
   public function actualizar($id,request $datos){
    $alumnos=modeloalumnos::find($id);
    $alumnos->nombre=$datos->input('nombre');
    $alumnos->numero_control=$datos->input('control');
    $alumnos->edad=$datos->input('edad');
    $alumnos->sexo=$datos->input('sexo');
    $alumnos->carrera_id=$datos->input('carrera');
    $alumnos->save();
    return redirect('consultarAlumno');
   }

   public function pdf(){
     $alumnos=modeloalumnos::all();
     $vista=view('alumnosPDF',compact('alumnos'));
     $pdf=\App::make('dompdf.wrapper');
     $pdf->loadHTML($vista);
     return $pdf->stream('ListaAlumnos.pdf');
   }
}

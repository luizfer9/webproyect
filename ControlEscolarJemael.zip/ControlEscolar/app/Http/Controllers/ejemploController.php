<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class ejemploController extends Controller
{
    public function index(){
    	$edad=22;
    	$nombre="Georgina";
    	return view('ejemplo1',compact('edad','nombre'));
    }
}

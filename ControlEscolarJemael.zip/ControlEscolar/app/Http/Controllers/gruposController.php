<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\modelogrupos;
use App\modelomaestros;
use App\modelomaterias;
use DB;

class gruposController extends Controller
{
    public function registrar(){
    	$maestros=modelomaestros::all();
    	$materias=modelomaterias::all();

    	//$alxgr=alumnoxgrupos::all();
    	return view('registrarGrupo',compact('maestros','materias'));
    }
    public function guardar(Request $datos){
    	$grupo=new modelogrupos();
    	$grupo->aula=$datos->input('aula');
    	$grupo->horario=$datos->input('horario');
    	$grupo->maestro_id=$datos->input('maestro');
    	$grupo->materia_id=$datos->input('materia');
    	$grupo->save();

    	return redirect('/ejemplo2');
    }
    public function consultar(){
    	$grupos=DB::table('grupos')
    	->join('maestros','grupos.maestro_id','=','maestros.id')
    	->join('materias','maestros.materia_id','=','materias.id')
     	->select('grupos.*','maestros.nombre AS nom_maestro','materias.nombre AS nom_materia')
    	->paginate(5);

    	return view('consultarGrupo',compact('grupos'));
    }
    public function eliminar($id){
      $grupos=modelogrupos::find($id);
      $grupos->delete();
      return redirect('consultarGrupo');
    }
      public function editar($id){
      $grupos=DB::table('grupos')
         ->where('grupos.id', '=', $id)
         ->join('maestros','grupos.maestro_id','=','maestros.id')
    	 ->join('materias','grupos.materia_id','=','materias.id')
     	 ->select('grupos.*','maestros.nombre AS nom_maestro','materias.nombre AS nom_materia')
         ->first();
				 $maestros=modelomaestros::all();
				 $materias=modelomaterias::all();
      return view('editarGrupo', compact('grupos','maestros','materias'));
    }
   	public function actualizar($id, Request $datos){
      //dd($datos);no envia aula
      $grupos=modelogrupos::find($id);
      $grupos->aula=$datos->input('aula');
      $grupos->horario=$datos->input('horario');
      $grupos->maestro_id=$datos->input('maestro');
      $grupos->materia_id=$datos->input('materia');
      $grupos->save();
      return redirect('consultarGrupo');
   	}

    public function pdf(){
      $grupos=modelogrupos::all();
      $vista=view('gruposPDF',compact('grupos'));
      $pdf=\App::make('dompdf.wrapper');
      $pdf->loadHTML($vista);
      return $pdf->stream('ListaGrupos.pdf');
    }
}

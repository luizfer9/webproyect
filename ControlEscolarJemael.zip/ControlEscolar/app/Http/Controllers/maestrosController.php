<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\modelomaterias;
use App\modelomaestros;
use DB;

class maestrosController extends Controller
{
   public function registrar(){
     $materias=modelomaterias::all();
   	return view('registrarMaestro', compact('materias'));
   }

   public function guardar(Request $datos){
     $maestros=new modelomaestros();
     $maestros->nombre=$datos->input('nombre');
     $maestros->numero_control=$datos->input('control');
     $maestros->edad=$datos->input('edad');
     $maestros->sexo=$datos->input('sexo');
     $maestros->materia_id=$datos->input('materia');
     $maestros->save();
     return redirect('/ejemplo2');
   }
   public function consultar (){
    // $alumnos=modeloalumnos::paginate(5);
    $maestros=DB::table ('maestros')
    ->join('materias','maestros.materia_id','=','materias.id')
    ->select('maestros.*','materias.nombre AS nom_materia')
    ->paginate(5);
     return view('consultarMaestro',compact('maestros'));
   }
   public function eliminar ($id){
     $maestros=modelomaestros::find($id);
     //dd($alumnos);
     $maestros->delete();
     return redirect('consultarMaestro');
   }
   public function editar ($id){
     $maestros=DB::table ('maestros')
     ->where('maestros.id','=',$id)
     ->join('materias','maestros.materia_id','=','materias.id')
     ->select('maestros.*','materias.nombre AS nom_materia')
     ->first();
     $materias=modelomaterias::all();
     return view('editarMaestro',compact('maestros','materias'));
   }
   public function actualizar($id,request $datos){
    $maestros=modelomaestros::find($id);
    $maestros->nombre=$datos->input('nombre');
    $maestros->numero_control=$datos->input('control');
    $maestros->edad=$datos->input('edad');
    $maestros->sexo=$datos->input('sexo');
    $maestros->materia_id=$datos->input('materia');
    $maestros->save();
    return redirect('consultarMaestro');
   }

   public function pdf(){
     $maestros=modelomaestros::all();
     $vista=view('maestrosPDF',compact('maestros'));
     $pdf=\App::make('dompdf.wrapper');
     $pdf->loadHTML($vista);
     return $pdf->stream('ListaMaestros.pdf');
   }
}

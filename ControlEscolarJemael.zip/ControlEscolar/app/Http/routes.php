<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|Ruta->Vista->Controlador
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('ejemplo2', 'homecontroller@index');

Route::get('/registrarAlumno', 'alumnoscontroller@registrar');
Route::post('/guardarAlumno','alumnoscontroller@guardar');
Route::get('/consultarAlumno', 'alumnoscontroller@consultar');
Route::get('/eliminarAlumno/{id}', 'alumnoscontroller@eliminar');
Route::get('/editarAlumno/{id}', 'alumnoscontroller@editar');
Route::post('/actualizarAlumno/{id}','alumnoscontroller@actualizar');
Route::get('/pdfAlumnos','alumnoscontroller@pdf');

Route::get('/registrarMaestro', 'maestrosController@registrar');
Route::post('/guardarMaestro','maestrosController@guardar');
Route::get('/consultarMaestro', 'maestrosController@consultar');
Route::get('/eliminarMaestro/{id}', 'maestrosController@eliminar');
Route::get('/editarMaestro/{id}', 'maestrosController@editar');
Route::post('/actualizarMaestro/{id}','maestrosController@actualizar');
Route::get('/pdfMaestros','maestrosController@pdf');

Route::get('/registrarGrupo', 'gruposController@registrar');
Route::post('/guardarGrupo','gruposController@guardar');
Route::get('/consultarGrupo', 'gruposController@consultar');
Route::get('/eliminarGrupo/{id}', 'gruposController@eliminar');
Route::get('/editarGrupo/{id}', 'gruposController@editar');
Route::post('/actualizarGrupo/{id}','gruposController@actualizar');
Route::get('/pdfGrupos','gruposController@pdf');

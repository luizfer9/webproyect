<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modeloalumnos extends Model
{
    protected $table='alumnos';
}

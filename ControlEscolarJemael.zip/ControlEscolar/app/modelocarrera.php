<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modelocarrera extends Model
{
    protected $table='carreras';
}
//php artisan make:model nombremodelo

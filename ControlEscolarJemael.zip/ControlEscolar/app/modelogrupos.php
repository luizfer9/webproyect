<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modelogrupos extends Model
{
    protected $table='grupos';
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modelomaestros extends Model
{
    protected $table='maestros';
}

@extends('master')

@section('contenido')
<form action="{{url('/actualizarMaestro')}}/{{$maestros->id}}" method="post">
	<input id="token" type="hidden" name="_token" value="{{csrf_token()}}">
	<div class="form-group">
		<label for="nombre">Nombre:</label>
		<input type="text" class="form-control" name="nombre"required value="{{$maestros->nombre}}">
	</div>
	<div class="form-group">
		<label for="control">Numero de control:</label>
		<input type="text" class="form-control" name="control" required value="{{$maestros->numero_control}}">

	</div>
	<div class="form-group">
		<label for="edad">Edad:</label>
		<input type="number" class="form-control" name="edad" required value="{{$maestros->edad}}">

	</div>
	<div class="form-group">
		<label for="sexo">Sexo:</label>
		<select name="sexo" class="form-control">
			@if($maestros->sexo==0)
			<option value="0" selected>Mujer</option>
			<option value="1">Masculino</option>
			@else
			<option value="0">Femenino</option>
			<option value="1"selected>Masculino</option>
			@endif
		</select>
	</div>

	<div class="form-group">
		<label for="materia">Materia:</label>
		<select name='materia' class="form-control">
			<option value="{{$maestros->materia_id}}">{{$maestros->nom_materia}}</option>
			@foreach($materias as $mat)
				<option value="{{$mat->id}}">{{$mat->nombre}}</option>
			@endforeach
		</select>
	</div>

<div>
	<button type="submit" class="btn btn-primary">Actualizar</button>
	<a href="{{url('/ejemplo2')}}" class="btn btn-danger">Cancelar</a>
</div>
</form>
@stop

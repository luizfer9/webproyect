@extends('master')

@section('contenido')
<form action="{{url('/guardarAlumno')}}" method="post">
	<input id="token" type="hidden" name="_token" value="{{csrf_token()}}">
	<div class="form-group">
		<label for="nombre">Nombre:</label>
		<input type="text" class="form-control" name="nombre">
	</div>
	<div class="form-group">
		<label for="control">Numero de control:</label>
		<input type="text" class="form-control" name="control" required>

	</div>
	<div class="form-group">
		<label for="edad">Edad:</label>
		<input type="number" class="form-control" name="edad" required>

	</div>
	<div class="form-group">
		<label for="sexo">Sexo:</label>
		<select name="sexo" class="form-control">
			<option value="0" selected="">Mujer</option>
			<option value="1" selected="">Masculino</option>
		</select>
	</div>

<div class="form-group">
	<label for="carrera">Carrera:</label>
	<select name='carrera' class="form-control">
		@foreach($carreras as $c)
		<option value="{{$c->id}}">{{$c->nombre}}</option>
		@endforeach
	</select>
</div>

<div>
	<button type="submit" class="btn btn-primary">Resgistrar</button>
	<a href="{{url('/ejemplo2')}}" class="btn btn-danger">Cancelar</a>
</div>
</form>

@stop

<?php $__env->startSection('contenido'); ?>
<form action="<?php echo e(url('/guardarGrupo')); ?>" method="POST">
<input id="token" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<div class="form-group">
		<label for="aula">Aula:</label>
			<input type="text" class="form-control" name="aula" required>
	</div>	<div class="form-group">
		<label for="horario">Horario:</label>
			<input type="time" class="form-control" name="horario" value="07:00:00" min="07:00:00" max="19:00:00" required>
	</div>
	<div class="form-group">
		<label for="maestro">Maestro:</label>
			<select name="maestro" class="form-control">
				<?php foreach($maestros as $m): ?>
					<option value="<?php echo e($m->id); ?>"><?php echo e($m->nombre); ?></option>
				<?php endforeach; ?>
			</select>
	</div>
	<div class="form-group">
		<label for="materia">Materia:</label>
			<select name="materia" class="form-control">
				<?php foreach($materias as $mat): ?>
					<option value="<?php echo e($mat->id); ?>"><?php echo e($mat->nombre); ?></option>
				<?php endforeach; ?>
			</select>
	</div>
	<div>
		<button type="submit" class="btn btn-primary">Registrar</button>
		<a href="<?php echo e(url('/ejemplo2')); ?>" class="btn btn-danger">Cancelar</a>
	</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
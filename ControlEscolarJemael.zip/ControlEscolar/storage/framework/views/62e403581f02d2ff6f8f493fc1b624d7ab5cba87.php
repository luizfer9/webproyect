<?php $__env->startSection('contenido'); ?>
<table class= "table table-striped">
  <thead>
    <tr>
      <th>ID</th>
      <th>Nombre</th>
      <th>Numero de control</th>
      <th>Edad</th>
      <th>Sexo</th>
      <th>Materia</th>
      <th>Opciones</th>
      <th><a href="<?php echo e(url('/pdfMaestros')); ?>">PDF</a></th>

    </tr>
    <?php foreach($maestros as $m): ?>
    <tr>
      <td><?php echo e($m->id); ?></td>
      <td><?php echo e($m->nombre); ?></td>
      <td><?php echo e($m->numero_control); ?></td>
      <td><?php echo e($m->edad); ?></td>
      <td><?php if($m->sexo==0): ?>
              Femenino
          <?php else: ?>
              Masculino
          <?php endif; ?></td>
          <td><?php echo e($m->nom_materia); ?></td>
      <td>
					<a href="<?php echo e(url('/editarMaestro')); ?>/<?php echo e($m->id); ?>" class="btn btn-primary btn-xs">
						<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
					</a>
					<a href="<?php echo e(url('/eliminarMaestro')); ?>/<?php echo e($m->id); ?>" class="btn btn-danger btn-xs">
						<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
					</a>
				</td>
			</tr>
    <?php endforeach; ?>
  </thead>
</table>
<div class="text-center">
  <?php echo e($maestros->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
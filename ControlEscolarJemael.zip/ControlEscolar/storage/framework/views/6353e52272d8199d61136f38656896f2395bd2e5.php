<?php $__env->startSection('contenido'); ?>
<table class="table table-striped">
	<thead>
		<tr>
			<th>ID</th>
			<th>Aula</th>
			<th>Horario</th>
			<th>Maestro</th>
			<th>Materia</th>
			<th>Opciones</th>
			<th><a href="<?php echo e(url('/pdfGrupos')); ?>">PDF</a></th>

		</tr>
		<?php foreach($grupos as $g): ?>
			<tr>
				<td><?php echo e($g->id); ?></td>
				<td><?php echo e($g->aula); ?></td>
				<td><?php echo e($g->horario); ?></td>
				<td><?php echo e($g->nom_maestro); ?></td>
				<td><?php echo e($g->nom_materia); ?></td>
				<td>
					<a href="<?php echo e(url('/editarGrupo')); ?>/<?php echo e($g->id); ?>" class="btn btn-primary btn-xs">
						<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
					</a>
					<a href="<?php echo e(url('/eliminarGrupo')); ?>/<?php echo e($g->id); ?>" class="btn btn-danger btn-xs">
						<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
					</a>
				</td>
			</tr>
		<?php endforeach; ?>
	</thead>
</table>
<div class="text-center">
	<?php echo e($grupos->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('contenido'); ?>
<form action="<?php echo e(url('/actualizarMaestro')); ?>/<?php echo e($maestros->id); ?>" method="post">
	<input id="token" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<div class="form-group">
		<label for="nombre">Nombre:</label>
		<input type="text" class="form-control" name="nombre"required value="<?php echo e($maestros->nombre); ?>">
	</div>
	<div class="form-group">
		<label for="control">Numero de control:</label>
		<input type="text" class="form-control" name="control" required value="<?php echo e($maestros->numero_control); ?>">

	</div>
	<div class="form-group">
		<label for="edad">Edad:</label>
		<input type="number" class="form-control" name="edad" required value="<?php echo e($maestros->edad); ?>">

	</div>
	<div class="form-group">
		<label for="sexo">Sexo:</label>
		<select name="sexo" class="form-control">
			<?php if($maestros->sexo==0): ?>
			<option value="0" selected>Mujer</option>
			<option value="1">Masculino</option>
			<?php else: ?>
			<option value="0">Femenino</option>
			<option value="1"selected>Masculino</option>
			<?php endif; ?>
		</select>
	</div>

	<div class="form-group">
		<label for="materia">Materia:</label>
		<select name='materia' class="form-control">
			<option value="<?php echo e($maestros->materia_id); ?>"><?php echo e($maestros->nom_materia); ?></option>
			<?php foreach($materias as $mat): ?>
				<option value="<?php echo e($mat->id); ?>"><?php echo e($mat->nombre); ?></option>
			<?php endforeach; ?>
		</select>
	</div>

<div>
	<button type="submit" class="btn btn-primary">Actualizar</button>
	<a href="<?php echo e(url('/ejemplo2')); ?>" class="btn btn-danger">Cancelar</a>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('contenido'); ?>
<table class= "table table-striped">
  <thead>
    <tr>
      <th>ID</th>
      <th>Nombre</th>
      <th>Numero de control</th>
      <th>Edad</th>
      <th>Sexo</th>
      <th>Carrera</th>
      <th>Opciones</th>
      <th><a href="<?php echo e(url('/pdfAlumnos')); ?>">PDF</a></th>
    </tr>
    <?php foreach($alumnos as $a): ?>
    <tr>
      <td><?php echo e($a->id); ?></td>
      <td><?php echo e($a->nombre); ?></td>
      <td><?php echo e($a->numero_control); ?></td>
      <td><?php echo e($a->edad); ?></td>
      <td><?php if($a->sexo==0): ?>
              Femenino
          <?php else: ?>
              Masculino
          <?php endif; ?></td>
      <td><?php echo e($a->nom_carrera); ?></td>
      <td>
					<a href="<?php echo e(url('/editarAlumno')); ?>/<?php echo e($a->id); ?>" class="btn btn-primary btn-xs">
						<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
					</a>
					<a href="<?php echo e(url('/eliminarAlumno')); ?>/<?php echo e($a->id); ?>" class="btn btn-danger btn-xs">
						<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
					</a>
				</td>
			</tr>
    <?php endforeach; ?>
  </thead>
</table>
<div class="text-center">
  <?php echo e($alumnos->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
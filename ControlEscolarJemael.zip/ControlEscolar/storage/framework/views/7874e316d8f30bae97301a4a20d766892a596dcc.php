<!DOCTYPE html>
<html>
<head>	
	<title>Vista ejemplo</title>
</head>
<body>
 <div class="container">
 	<div class="row well"></div>
 	<h1>Ejemplo de view</h1>
 	<h2>Nombre: <?php echo e($nombre); ?></h2>
 	<h2>Edad: <?php echo e($edad); ?></h2>
 	<div class="from-group">
 		
 	</div>

 </div>
</body>
</html>
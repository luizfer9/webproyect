<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Reporte de Maestros</title>
    <style>
      .encabezado{
        color: blue;
        background-color: black;
      }
    </style>
  </head>
  <body>
    <img src="img/logo.png" width="150px" alt="">
    <h1>Lista de maestros</h1>
    <hr>
    <?php foreach($maestros as $m): ?>
      <?php echo e($m->nombre); ?><br>
    <?php endforeach; ?>
  </body>
</html>

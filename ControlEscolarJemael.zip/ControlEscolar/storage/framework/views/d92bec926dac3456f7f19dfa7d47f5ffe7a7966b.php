<?php $__env->startSection('contenido'); ?>
<form action="<?php echo e(url('/guardarAlumno')); ?>" method="post">
	<input id="token" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<div class="form-group">
		<label for="nombre">Nombre:</label>
		<input type="text" class="form-control" name="nombre">
	</div>
	<div class="form-group">
		<label for="control">Numero de control:</label>
		<input type="text" class="form-control" name="control" required>

	</div>
	<div class="form-group">
		<label for="edad">Edad:</label>
		<input type="number" class="form-control" name="edad" required>

	</div>
	<div class="form-group">
		<label for="sexo">Sexo:</label>
		<select name="sexo" class="form-control">
			<option value="0" selected="">Mujer</option>
			<option value="1" selected="">Masculino</option>
		</select>
	</div>

<div class="form-group">
	<label for="carrera">Carrera:</label>
	<select name='carrera' class="form-control">
		<?php foreach($carreras as $c): ?>
		<option value="<?php echo e($c->id); ?>"><?php echo e($c->nombre); ?></option>
		<?php endforeach; ?>
	</select>
</div>

<div>
	<button type="submit" class="btn btn-primary">Resgistrar</button>
	<a href="<?php echo e(url('/ejemplo2')); ?>" class="btn btn-danger">Cancelar</a>
</div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>